# Crownfall v0.2.3 — Schritt 11: Pixel-Art und Animationen

Vollständige GitHub-Pages-Version auf Basis von Schritt 10. Alle bisherigen Spielsysteme und der localStorage-Spielstand bleiben erhalten.

## Neu
- Eigene pixelgenaue Texturen für Held, Pferd, sieben Bewohnerdarstellungen, Hollowling, Lagerfeuer und zehn Gebäude
- Lauf-, Reit-, Stand- und Gegneranimationen mit diskreten Frames
- Gebäudegrafiken statt farbiger Rechtecke
- Texturen werden beim Start lokal per Canvas generiert (keine externen Grafik-Downloads)
- `art.js` getrennt von der Spiellogik, damit später Spritesheets einfach ausgetauscht werden können

## GitHub Pages
Alle Dateien in den Root des Repositories hochladen, GitHub Pages auf `main` / `(root)` stellen und die Seite in iPhone Safari im Querformat öffnen. Beim ersten Start ist Internet nötig, weil Phaser 3.90 über CDN geladen wird.

## Grenzen
Die Hintergrundlandschaft basiert noch auf dem bestehenden Grafikcode. Animationen sind einfache zweibildrige bis vierbildrige Pixel-Art-Zyklen. Performance und Darstellung müssen auf echtem iPhone geprüft werden.
